// Deprecated warning for inject.bundle.js
/* eslint-disable no-console */
console.warn(
  'Using Redux DevTools inside extensions is deprecated and won\'t be supported in the next major version. ' +
  'Please use https://github.com/zalmoxisus/remote-redux-devtools instead.'
);
/* eslint-enable no-console */
