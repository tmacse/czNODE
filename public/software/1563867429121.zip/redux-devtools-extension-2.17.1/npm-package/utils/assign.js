var objectKeys = Object.keys || function (obj) {
    var keys = [];
    for (var key in obj) {
      if ({}.hasOwnProperty.call(obj, key)) keys.push(key);
    }
    return keys;
  };

function assign(obj, newKey, newValue) {
  var keys = objectKeys(obj);
  var copy = {};

  for (var i = 0, l = keys.length; i < l; i++) {
    var key = keys[i];
    copy[key] = obj[key];
  }

  copy[newKey] = newValue;
  return copy;
}

module.exports = assign;
